import{o as a}from"./mermaid-parser.core-C-Rz0q2j.js";import"./chunk-NGNAAXSQ-DzGwYJ5G.js";export{a as createTreemapServices};
