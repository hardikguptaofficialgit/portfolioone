import{M as r}from"./mermaid-parser.core-C-Rz0q2j.js";import"./chunk-NGNAAXSQ-DzGwYJ5G.js";export{r as createArchitectureServices};
